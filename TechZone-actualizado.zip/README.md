TechZone es una aplicación web Frontend interactiva de comercio tecnológico que simula de principio a fin la experiencia de usuario de un e-commerce real. Cuenta con un catálogo renderizado dinámicamente, filtros cruzados por categorías y palabras clave, un motor funcional de carrito de compras con control de cantidades, un validador de cupones promocionales con cálculos matemáticos en tiempo real y formularios de comunicación con doble capa de seguridad estética y funcional.
Autores:
Davila Medina Gianfranco Giovanni, 
Salazar Cornetero Fabricio
